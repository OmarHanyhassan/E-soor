import 'package:flutter/material.dart';


class Chats extends StatefulWidget {
	@override
	_ChatsState createState() => _ChatsState();
}

class _ChatsState extends State<Chats> {
	@override
	Widget build(BuildContext context) {
		return Container(
			child: Text("This is Chats page", style: TextStyle(fontSize: 30),),
		);
	}
}
