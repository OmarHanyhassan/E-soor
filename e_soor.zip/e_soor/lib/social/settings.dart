import 'package:flutter/material.dart';


class Settings extends StatefulWidget {
	@override
	_SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
	@override
	Widget build(BuildContext context) {
		return Container(
			child: Text("This is Settings page", style: TextStyle(fontSize: 30),),
		);
	}
}
