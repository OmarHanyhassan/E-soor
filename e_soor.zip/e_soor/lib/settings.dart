import 'package:flutter/material.dart';

class Settings extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        // TODO: implement build
        return Scaffold(
            appBar: AppBar(
                title: Text("Settings"),
            ),
            body: Text("Hola"),
        );
    }
}